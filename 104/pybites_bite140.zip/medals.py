import pandas as pd

data = "http://projects.bobbelderbos.com/data/summer.csv"


def athletes_most_medals():
    pass